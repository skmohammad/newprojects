import React, { Component } from 'react';

class FooterComp extends Component {
  render() {
    return (
      <div className="footer">
        @ Powered by Mifer Dang
      </div>
    );
  }
}

export default FooterComp;
